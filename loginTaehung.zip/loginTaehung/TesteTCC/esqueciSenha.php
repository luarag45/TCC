<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esqueci a senha</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container-quadrado">
        <h2>Esqueceu a senha?</h2>
        <p>Digite seu e-mail abaixo e enviaremos um link para redefinir sua senha.</p>
         <form action="">
         <div class="form-group">
             <label for="">Email</label>
             <input type="text">
         </div>
         
         <button type="submit" class="btn-login">Enviar link de recuperação</button>
         </form>

         <div class="divider"></div>

         <a href="login.php">Voltar para o login</a>
    </div>
</body>
</html>