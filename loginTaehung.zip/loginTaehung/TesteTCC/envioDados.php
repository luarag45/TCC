<?php
require 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome             = $_POST['nome'];
    $nasc             = $_POST['nasc'];
    $email            = $_POST['email'];
    $telefone         = $_POST['telefone'];
    $senha            = $_POST['senha'];
    $confirmar_senha  = $_POST['confirmar_senha'];

    // Validação simples
    if (empty($nome) || empty($email) || empty($senha)) {
        die("Preencha todos os campos obrigatórios.");
    }

    // Verifica as senhas
    if ($senha !== $confirmar_senha) {
        echo "As senhas não estão iguais";
        exit;
    }

    $senha_hash = password_hash($senha, PASSWORD_DEFAULT); // Criptografa a senha 

    // Usa prepared statement para evitar SQL Injection
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, nasc, email, telefone, senha) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nome, $nasc, $email, $telefone, $senha_hash);

    if ($stmt->execute()) {
        echo "Usuário cadastrado com sucesso!";
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>