

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tela de Cadastro</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="envio">
</head>
<body class="animated-bg">
  <div class="cadastro-container">
    <h2>Cadastre-se Aqui!</h2>
    <p>Crie sua conta e junte-se a nós</p>

    <!-- INPUT´S-->

    <form action="envioDados.php" method="POST">
      <div class="form-grid">
        <div class="form-group">
          <label for="nome">Nome completo</label>
          <input type="text" id="nome" name="nome" required/>
        </div>
        <div class="form-group">
          <label for="nascimento">Data de nascimento</label>
          <input type="date" id="nascimento" name="nasc" />
        </div>
        <div class="form-group">
          <label for="telefone">Telefone</label>
          <input type="tel" id="telefone" name="telefone" required/>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required/>
        </div>
        <div class="form-group">
          <label for="senha">Senha</label>
          <input type="password" id="senha" name="senha" required/>
        </div>
        <div class="form-group">
          <label for="senha">Confirmar senha</label>
          <input type="password" id="confirmar_senha" name="confirmar_senha" required/>
        </div>
      </div>
      

      <!-- Botões -->

      <button type="submit" class="btn-cadastrar">Cadastrar</button>

      <div class="divider">Ou cadastre-se com</div>

      <button type="oi" class="btn-google">Continue com google</button>
    </form>

    <p style="margin-top: 10px; font-size: 13px;">
      Já tem uma conta? <a href="login.php">Fazer login</a>
    </p>

  </div>
</body>
</html>