<?php

session_start();
require "conexao.php";

    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';


    //Procura o banco de dados para comparar as variaveis do usuário
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    //aqui se o usuário for encontrado ele armazena a informação na variavel user   
    if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

     // Conferi a senha com password_verify
    if (password_verify($senha, $user['senha'])) {
        // Cria a sessão
        $_SESSION['usuario_id'] = $user['id'];
        $_SESSION['usuario_nome'] = $user['nome'];

        
        header("Location: area_restrita.php");

        exit;
    } else {
        echo "Senha incorreta.";
    }
    } else {
    echo "Usuário não encontrado.";
    }

$stmt->close();
$conn->close();

?>