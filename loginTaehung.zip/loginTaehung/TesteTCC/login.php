
<!DOCTYPE html>
<html lang="Pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
    <!--Tela de login teste-->

    <div class="container-quadrado">
       <h2>Entrar no sistema</h2>
        <form action="autenticar.php" method="POST">
        <div class="form-group">
            <label for="">Email</label>
            <input type="text" name="email" required>
        </div>
        <div class="form-group">
            <label for="">Senha</label>
            <input type="text" name="senha" required>
        </div>
        <button type="submit" class="btn-login">Logar</button>
        </form>
        <div class="divider">Ou entre com</div>

      <button type="submit" class="btn-google">Continue com google</button>
    </form>

        <p style="margin-top: 10px; font-size: 13px;">
            Já tem uma conta? <a href="cadastro.php">Não tem cadastro</a> 
          </p>
          <a href="esqueciSenha.php">Esqueci a senha</a>
    </div>

</body>
</html>
