<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tela de Cadastro</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
  <div class="cadastro-container">
    <h2>Cadastre-se Aqui!</h2>
    <p>Crie sua conta e junte-se a nós</p>

    <!-- INPUT´S-->

    <form action="cadastro.php" method="post">
      <div class="form-grid">
        <div class="form-group">
          <label for="nome">Nome completo</label>
          <input type="text" id="nome" />
        </div>
        <div class="form-group">
          <label for="nascimento">Data de nascimento</label>
          <input type="date" id="nascimento" />
        </div>
        <div class="form-group">
          <label for="telefone">Telefone</label>
          <input type="tel" id="telefone" />
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" />
        </div>
        <div class="form-group">
          <label for="senha">Senha</label>
          <input type="password" id="senha" />
        </div>
        <div class="form-group">
          <label for="senha">Confirmar senha</label>
          <input type="password" id="senha" />
        </div>
      </div>
      

      <!-- Botões -->

      <button type="submit" class="btn-cadastrar">Cadastrar</button>

      <div class="divider">Ou cadastre-se com</div>

      <button type="submit" class="btn-google">Continue com google</button>
    </form>

    <p style="margin-top: 10px; font-size: 13px;">
      Já tem uma conta? <a href="login.php">Fazer login</a>
    </p>
    </form>
  </div>
</body>
</html>

<?php
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome     = $_POST['nome'];
    $nasc     = $_POST['nasc'];
    $email    = $_POST['email'];
    $telefone = $_POST['telefone'];
    $senha    = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografa a senha

    $sql = "INSERT INTO usuarios (nome, nasc, email, telefone, senha) 
            VALUES ('$nome', '$nasc', '$email', '$telefone', '$senha')";

    if ($conn->query($sql) === TRUE) {
        echo "Usuário cadastrado com sucesso!";
    } else {
        echo "Erro: " . $conn->error;
    }
}
?>

